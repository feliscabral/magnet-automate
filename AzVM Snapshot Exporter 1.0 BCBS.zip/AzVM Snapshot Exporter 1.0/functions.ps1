function LogThis($text) {
    $message = "[$PluginName] $((Get-Date).ToString("yyyy-MM-dd-hh:mm:ss")) $text"
    try {
        Write-Output "$message"    
        Write-Output "$message" >> "$TempPath\log.txt"
    }
    catch {
        Write-Output "  >> PLUGIN ERROR: Cannot write log file [$TempPath\log.txt] - $_"
        Exit 3
    }
}


# =====================
# Authenticate FUNCTION
# Gets token from azure.
# =====================
$script:AuthState = @{
	AccessToken = $null
	ExpiresOn   = $null
}
function Authenticate {
	$refreshNeeded = $false
	if (-not $script:AuthState.AccessToken) {
		$refreshNeeded = $true
	} elseif (-not $script:AuthState.ExpiresOn) {
		$refreshNeeded = $true
	} elseif ((Get-Date) -ge $script:AuthState.ExpiresOn) {
		$refreshNeeded = $true
	}
	
	if ($refreshNeeded) {
		LogThis "  >> Getting Azure token..."
		try {
			$body = @{
				client_id	  = $ClientId
				client_secret = $ClientSecret
				scope		  = "https://management.azure.com/.default"
				grant_type    = "client_credentials"
			}
			
			$response = Invoke-RestMethod `
										  -Method Post `
										  -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
										  -Body $body
			
			$script:AuthState.AccessToken = $response.access_token
			$script:AuthState.ExpiresOn = (Get-Date).AddSeconds($response.expires_in - 300)			
			
		}catch {
			LogThis "  >> PLUGIN ERROR: Failed to get Azure token: $_. Exiting with code 3."
			Exit 3
		}
	}
}


# =====================
# Get-Subscriptions FUNCTION
# Gets a list of all subscriptions that are
# granted access to the application id
# =====================
$script:Subscriptions = @()
function Get-Subscriptions {
	Authenticate
	$headers = @{Authorization = "Bearer $($script:AuthState.AccessToken)"}
	$response = Invoke-RestMethod `
								  -Method Get `
								  -Uri "https://management.azure.com/subscriptions?api-version=2020-01-01" `
								  -Headers $headers
	$script:Subscriptions = $response.value
    if($response.count.value -eq 0){LogThis "  >> PLUGIN ERROR: Cannot find access to any subscriptions. Exting with code 4.";Exit 4}
    LogThis "  >> Found access to [$($response.count.value)] subscription(s)."
}



# =====================
# Get-VMs FUNCTION
# Gets all VMs from all subscriptioins
# =====================
$script:VMs = @()
function Get-VMs {
	Authenticate
	$headers = @{Authorization = "Bearer $($script:AuthState.AccessToken)"}
	
	$script:VMs = @()
	foreach ($sub in $script:Subscriptions) {
		#LogThis "  >> Getting VMs from [$($sub.displayName)]"
		$response = Invoke-RestMethod `
									  -Method Get `
									  -Uri "https://management.azure.com/subscriptions/$($sub.subscriptionId)/providers/Microsoft.Compute/virtualMachines?api-version=2024-03-01" `
									  -Headers $headers
		$vmList = $response.value | ForEach-Object {
			[PSCustomObject]@{
				Name		   = $_.name
				Id			   = $_.id
				Location	   = $_.location
				SubscriptionId = $sub.subscriptionId
				Subscription   = $sub.displayName
				ResourceGroup  = ($_.id -split '/')[4]
			}
		}
		$script:VMs += $vmList
	}
	LogThis "  >> Discovered [$($script:VMs.Count)] Virtual Machine(s) in [$($sub.displayName)]"
}



# =====================
# Find VMs Function
# This will find a VM once all have been
# queried from the Get-VMs function. All found
# will be placed in an array.
# Right now only 1 found VM Name is supported.
# Leaving as array for future support.
# =====================
$script:FoundVM = $null
function Find-VMByName {
	$FoundVMMatches = @($script:VMs | Where-Object {$_.Name -like $VirtualMachineName})
	if ($FoundVMMatches.count -eq 0) {LogThis "  >> PLUGIN ERROR: Cannot find Virtual Machine Name [$VirtualMachineName]. Exiting with code 5.";Exit 5}
	if ($FoundVMMatches.Count -gt 1) {
        LogThis "  >> PLUGIN ERROR: Found more than one Virtual Machine Name [$VirtualMachineName]:"
        $results = $FoundVMMatches | Select-Object Name, Location, Subscription, ResourceGroup | ConvertTo-Json
        LogThis $results
        LogThis " Exiting with code 6.";Exit 6
    }
    $script:FoundVM = $FoundVMMatches[0]
    LogThis "  >> Found [$($FoundVMMatches.Name)] in [$($FoundVMMatches.Location)] Subscription [$($FoundVMMatches.Subscription)] Resource Group [$($FoundVMMatches.ResourceGroup)]"
}


# =====================
# Get-VMDetails Functtion
# This will details from a single VM
# This is required before getting disk details
# =====================
$script:VMDetails = $null
function Get-VMDetails {
	Authenticate
	$headers = @{
		Authorization = "Bearer $($script:AuthState.AccessToken)"
	}
	$uri = "https://management.azure.com/subscriptions/$($script:FoundVM.SubscriptionId)/resourceGroups/$($script:FoundVM.ResourceGroup)/providers/Microsoft.Compute/virtualMachines/$($script:FoundVM.Name)?api-version=2024-03-01"
	try{
        $vmDetails = Invoke-RestMethod `
                                    -Method Get `
                                    -Uri $uri `
                                    -Headers $headers
        $script:VMDetails = $vmDetails
    } catch {
                LogThis "  >> PLUGIN ERROR: Cannot get Virtual Machine Details: $_. Exiting with code 7"; Exit 7
    }

}



# =====================
# This will get the OS disk details
# =====================
$script:OSDisk = $null
function Get-OSDisk {
	Authenticate
	$headers = @{Authorization = "Bearer $($script:AuthState.AccessToken)"}
    try{
        $uri = "https://management.azure.com/subscriptions/$($script:FoundVM.SubscriptionId)/resourceGroups/$($script:FoundVM.ResourceGroup)/providers/Microsoft.Compute/virtualMachines/$($script:FoundVM.Name)?api-version=2024-03-01"
        $vmDetails = Invoke-RestMethod `
                                    -Method Get `
                                    -Uri $uri `
                                    -Headers $headers
        $osDisk = $vmDetails.properties.storageProfile.osDisk

        $DiskId = $($VMDetails.properties.storageProfile.osDisk.managedDisk.id)
        $uri = "https://management.azure.com$DiskId`?api-version=2025-01-02"
        $response = Invoke-RestMethod `
                                    -Method Get `
                                    -Uri $uri `
                                    -Headers $headers
        $osDiskSizeGB = $response.properties.diskSizeGB

        $script:OSDisk = [PSCustomObject]@{
            Name = $osDisk.name
            Id = $osDisk.managedDisk.id
            Type = "OS"
            osType = $osDisk.osType
            SizeGB = $osDiskSizeGB
        }
    } catch {
        LogThis "  >> PLUGIN ERROR: Cannot get Disk Properties: $_. Exiting with code 8"; Exit 8
    }
}


# =====================
# New-Snapshot Function
# This will trigger the snapshot
# Snapshot Name Limits:
#   Length: 1–80 characters
#   Must start with an alphanumeric character
#   Must end with an alphanumeric character or underscore
#   Allowed characters: letters, numbers, underscores (_), periods (.), and hyphens (-)
# =====================
$script:Snapshot = $null # these are the results raw
function New-Snapshot {
	Authenticate
	$headers = @{
		Authorization  = "Bearer $($script:AuthState.AccessToken)"
		"Content-Type" = "application/json"
	}
	$snapshotName = "$($script:OSDisk.Name)-AUTOMATE"
	$body = @{
		location   = $script:FoundVM.Location
		properties = @{
			creationData = @{
				createOption	 = "Copy"
				sourceResourceId = $script:OSDisk.Id
			}
		}
	} | ConvertTo-Json -Depth 10

    # Where the snapshot will be saved into
    if($SaveSnapshotSubscriptionID -eq "same"){$tenant = $script:FoundVM.SubscriptionId}else{$tenant=$SaveSnapshotSubscriptionID}
    if($SaveSnapshotResourceGroupName -eq "same"){$resourcegroupname=$script:FoundVM.ResourceGroup}else{$resourcegroupname=$SaveSnapshotResourceGroupName}
	$uri = "https://management.azure.com/subscriptions/$($tenant)/resourceGroups/$($resourcegroupname)/providers/Microsoft.Compute/snapshots/$snapshotName`?api-version=2024-03-02"
    try{
        $response = Invoke-RestMethod `
								  -Method Put `
								  -Uri $uri `
								  -Headers $headers `
								  -Body $body
    } catch {LogThis "  >> PLUGIN ERROR: Error attempting to create Snapshot: $_. Exiting with code 9.";Exit 9}
    
    $script:Snapshot = $response
    LogThis "  >> Successfully sent request to create snapshot."
}

# =====================
# Get-Snapshot Function
# This will get the snapshot info so we can
# capture the current state/progress of it.
# =====================
function Get-SnapshotInfo {
	Authenticate
	$headers = @{
		Authorization = "Bearer $($script:AuthState.AccessToken)"
	}
	$uri = "https://management.azure.com$($script:Snapshot.id)?api-version=2024-03-02"

    try{
            $response = Invoke-RestMethod `
								  -Method Get `
								  -Uri $uri `
								  -Headers $headers
        return [PSCustomObject]@{
            Name			  = $response.name
            Id			      = $response.id
            Location		  = $response.location
            ProvisioningState = $response.properties.provisioningState
        }
    } catch {LogThis "  >> PLUGIN ERROR: Error attempting to get Snapshot information: $_. Exiting with code 10."; Exit 10}
}


# =====================
# WaitForSnapshot Function
# This wiill use the Get-SanpshotInfo function
# in a loop until the ProvisioningState equals
# "Succeeded"
# =====================
function Wait-ForSnapshot {
	do {
		Start-Sleep -Seconds 2
		$snapshot = Get-SnapshotInfo
		$state = $snapshot.ProvisioningState
		LogThis "  >> Snapshot state: $state"
	} while ($state -eq "Creating")
	if ($state -ne "Succeeded") {
		LogThis "  >> PLUGIN ERROR: Failed to wait for Snapshot success. Exiting with code 11"; Exit 11
	}
	LogThis "  >> Snapshot Complete."
}


# =====================
# Get-SnapshotExport
# =====================
$script:SnapshotExport = $null
function Get-SnapshotExport {
	LogThis "  >> Sending request to create SAS URL..."
    Start-Sleep -Seconds 15
	Authenticate
    $TimeoutSeconds = 300
		
	$headers = @{
		Authorization = "Bearer $($script:AuthState.AccessToken)"
		"Content-Type" = "application/json"
	}
	$beginAccessUri = "https://management.azure.com$($script:Snapshot.id)/beginGetAccess?api-version=2023-10-02"
	
	$body = @{
		access		      = "Read"
		durationInSeconds = [int]$($SASURTimeoutHours) * 3600
	} | ConvertTo-Json
	
	try {		
		# Invoke-WebRequest (not Invoke-RestMethod) to read response headers
		$initialResponse = Invoke-WebRequest -Uri $beginAccessUri -Method POST -Headers $headers -Body $body -UseBasicParsing -ErrorAction Stop
		
		if ($initialResponse.StatusCode -ne 202) {
			LogThis "  >> PLUGIN ERROR: Expected Status Code 202 when creating SAS URL, got $($initialResponse.StatusCode). Exiting with code 13."; Exit 13
		}
		
		$asyncOperationUrl = $initialResponse.Headers['Azure-AsyncOperation']
		if (-not $asyncOperationUrl) {
			# Some responses use Location instead
			$asyncOperationUrl = $initialResponse.Headers['Location']
		}
		
		if (-not $asyncOperationUrl) {
			LogThis "  >> PLUGIN ERROR: No Azure-AsyncOperation or Location header returned to poll for snapshot '$($script:Snapshot.name)' while trying to create SAS URL. Exiting with code 14.";Exit 14
		}
		
		LogThis "  >> Checking request status..."
		
		$elapsed = 0
		do {
			$PollIntervalSeconds = 5
			Start-Sleep -Seconds $PollIntervalSeconds
			$elapsed += $PollIntervalSeconds
			
			$pollResponse = Invoke-RestMethod -Uri $asyncOperationUrl -Method GET -Headers $headers -ErrorAction Stop
			
			LogThis "  >> Status: $($pollResponse.status) (elapsed: $elapsed seconds)"
			
			if ($elapsed -ge $TimeoutSeconds) {
				throw "Timed out after $TimeoutSeconds seconds waiting for SAS grant on snapshot '$($script:Snapshot.name)'."
			}
		} while ($pollResponse.status -eq 'InProgress')
		
		if ($pollResponse.status -ne 'Succeeded') {
			throw "SAS grant operation ended with status '$($pollResponse.status)' for snapshot '$($script:Snapshot.name)'. $($pollResponse.error | ConvertTo-Json -Depth 5)"
		}
		
		$sasUrl = $pollResponse.properties.output.accessSAS
		if (-not $sasUrl) {
			throw "Operation succeeded but no accessSAS found in response: $($pollResponse | ConvertTo-Json -Depth 5)"
		}
		
        $script:SnapshotExport = [PSCustomObject]@{
			Name             = $script:Snapshot.name
            SnapshotID       = $script:Snapshot.id
            SnapshotLocation = $script:Snapshot.location
            SnapshotSizeGB   = $script:OSDisk.SizeGB
			SasUrl	         = $sasUrl
			ExpiresInSec     = [int]$($SASURTimeoutHours) * 3600
            GeneratedAtTZ    = $(Get-TimeZone).DisplayName
			GeneratedAt      = $(Get-Date).DateTime
            GeneratedAtUTC   = $(Get-Date).ToUniversalTime().DateTime
            ExpireDate       = $(Get-Date).AddSeconds([int]$($SASURTimeoutHours) * 3600).DateTime
            ExpireDateUTC    = $(Get-Date).AddSeconds([int]$($SASURTimeoutHours) * 3600).ToUniversalTime().DateTime
		}
	} catch {
		LogThis  "  >> PLUGIN ERROR: Failed to generate SAS URL for snapshot [$($script:Snapshot.name)]: $($_.Exception.Message). Exiting with code 12";Exit 12
	}
	LogThis "  >> Snapshot SAS URL: $sasUrl"
}


# =====================
# Get-DownloadSnapshot
# =====================
$script:DownloadSnapshot = $null
function Get-DownloadSnapshot {
	param (
			$OutputFile,
			$LogLocation
		)
	$env:AZCOPY_LOG_LOCATION = $LogLocation

	LogThis "  >> Starting azcopy.exe"
	$process = Start-Process -FilePath $AZCopyFilePath -ArgumentList "copy $($script:SnapshotExport.SasUrl) $OutputFile" -NoNewWindow -PassThru -Wait
	$exit_code = $process.ExitCode

	if($exit_code -eq 0){
		LogThis "  >> azcopy.exe download finished."
	} else {
		LogThis "  >> ERROR: azcopy.exe did not exit gracefully, it exited with code $exit_code. Plugin is now exiting with code 16."; Exit 16
	}


}


# =====================
# Revoke-SasURL
# =====================
Function Revoke-AzSnapshotExport {
	$Uri = "https://management.azure.com$($script:Snapshot.id)/endGetAccess?api-version=2024-03-02"
	$Headers = @{
		"Authorization" = "Bearer $($script:AuthState.AccessToken)"
		"Content-Type"  = "application/json"
	}

	try {
		$Response = Invoke-RestMethod -Uri $Uri -Method Post -Headers $Headers -Body "{}" -ErrorAction Stop
		LogThis "  >> Successfully canceled SAS URL."
	} catch {LogThis "  >> PLUGIN ERROR: Failed to revoke snapshot export: $_. Exiting with code 17";Exit 17}
	Start-Sleep -Seconds 10
}


# =====================
# Remove Snapshot
# =====================
Function Remove-Snapshot {
		$Uri = "https://management.azure.com/$($script:Snapshot.id)?api-version=2025-01-02"
		$Headers = @{
			"Authorization" = "Bearer $($script:AuthState.AccessToken)"
		}
		
		try {
			$Response = Invoke-RestMethod -Uri $Uri -Method Delete -Headers $Headers -ErrorAction Stop
			LogThis "  >> Successfully sent delete request."
		} catch {LogThis "  >> PLUGIN ERROR: Failed to send delete request: $_. Exiting with code 18.";Exit 18}
}

# =====================
# Get Final Results
# =====================
function Get-FinalResults{
    $FinalResults = [PSCustomObject]@{
        VirtalMachine = $script:FoundVM
        SnapshotExport = $script:SnapshotExport
    }
	return $FinalResults
}