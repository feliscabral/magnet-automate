Clear-Host
Start-Sleep -Seconds 1

# CONFIGURE PLUGIN BASE PATH HERE
# THIS IS THE PATH WHERE THIS PLUGIN IS INSTALLED
$PluginPath = "${CENTRAL_STORAGE_PATH}\workflow_plugins\AzVM Snapshot Exporter 1.0"
$AZCopyFilePath = "$PluginPath\bin\azcopy.exe"


# Load Functions
. "$PluginPath\functions.ps1"

$PluginName                  = "AVD Snapshot Exporter"
$PluginDescription           = "Magnet AUTOMATE Plugin for creating and downloading Azure Virtual Desktop Snapshots by Magnet Forensics Professional Services, NA."
$PluginVersion               = "1.0"
$TempPath                    = "${OUTPUT_PATH}"
$FinalOutputPath             = "${FINAL_OUTPUT_PATH}"

$ConfigFilename              = "${CONFIG_FILENAME}" #"C:\automat_central_storage\workflow_plugins\AVD Snapshot Exporter 1.0\config\default.ps1"
$VirtualMachineName          = "${VIRTUAL_MACHINE_NAME}"
$EnableSASURL                = "${ENABLE_SASURL}"
$SASURTimeoutHours           = "${SASURL_TIMEOUT_HOURS}"
$EnableDownloadSnapshot      = "${ENABLE_DOWNLOAD_SNAPSHOT}"
$Snapshot_Save_Filename      = "${SNAPSHOT_SAVE_FILENAME}"
$DeleteSnapshotAfterDownload = "${DELETE_SNAPSHOT_AFTER_DOWNLOAD}"


LogThis ("=" * 80)
LogThis "$PluginName $PluginVersion"
LogThis $PluginDescription
LogThis ("=" * 80)
LogThis "[MAGNET AUTOMATE]"
LogThis ("-" * 80)
LogThis "                                Case Number: ${CASE_NUMBER}"
LogThis "                            Evidence Number: ${EVIDENCE_NUMBER}"
LogThis "                                     Run ID: ${RUN_ID}"
LogThis "                                  Temp Path: $TempPath"
LogThis "                          Final Output Path: $FinalOutputPath"
LogThis "                              Node Hostname: $env:COMPUTERNAME"
LogThis "                            Service Account: $($Env:USERNAME)"
LogThis "                           OS/Log Time Zone: $(Get-TimeZone)"
LogThis ""
LogThis ("-" * 80)
LogThis "[PLUGIN VARIABLES]"
LogThis ("-" * 80)
LogThis "                                Plugin Path: $PluginPath"
LogThis "                          AZ Copy File Path: $AZCopyFilePath"
LogThis "                            Config Filename: $ConfigFilename"
LogThis "                       Virtual machine name: $VirtualMachineName"
LogThis "                             Create SAS URL: $EnableSASURL"
LogThis "                    SAS URL timeout (hours): $SASURTimeoutHours"
LogThis "                          Download snapshot: $EnableDownloadSnapshot"
LogThis "                Download snapshot file path: $Snapshot_Save_Filename"
LogThis "  Delete snapshot from Azure after download: $DeleteSnapshotAfterDownload"
LogThis ""
LogThis ("-" * 80)
if ([string]::IsNullOrWhiteSpace($ConfigFilename) -or !(Test-Path $("$PluginPath\config\$ConfigFilename") -PathType Leaf)){LogThis "  >> PLUGIN ERROR: [Config filename] does not exist or is not accessible from this node. Exiting with code 1.";Exit 1} else {. $("$PluginPath\config\$ConfigFilename")}
LogThis "[CONFIG FILE]"
LogThis ("-" * 80)
LogThis "                                  File Path: $("$PluginPath\config\$ConfigFilename")"
LogThis "                  Configuration Description: $ConfigurationDescription"
LogThis "       Snapshot Service Principal Tenant ID: $TenantId"
LogThis "       Snapshot Service Principal Client ID: $ClientId"
LogThis "              Save Snapshot Subscription ID: $SaveSnapshotSubscriptionID"
LogThis "          Save Snapshot Resource Group Name: $SaveSnapshotResourceGroupName"
LogThis ("-" * 80)
LogThis "[EXECUTION]"
LogThis ("-" * 80)

if($EnableDownloadSnapshot -eq "true" -and !(Test-Path $AZCopyFilePath -PathType Leaf)){LogThis "  >> PLUGIN ERROR: Download Snapshot is enabled but AZCopy.exe not found. Exiting with code 2.";Exit 2}
Copy-Item -Path $AZCopyFilePath -Destination $TempPath
$AZCopyFilePath = Join-Path $TempPath $(Split-Path $AZCopyFilePath -Leaf)

Get-Subscriptions
Get-VMs
Find-VMByName
Get-VMDetails
Get-OSDisk
New-Snapshot
Wait-ForSnapshot

if($EnableSASURL -eq "true"){
    Get-SnapshotExport
    if($EnableDownloadSnapshot -eq "true"){
        Get-DownloadSnapshot $Snapshot_Save_Filename $TempPath
    }
    if($DeleteSnapshotAfterDownload -eq "true"){
        Revoke-AzSnapshotExport
        Remove-Snapshot
    }
}


$FinalResults = Get-FinalResults | ConvertTo-Json
Set-Content -Path "$TempPath\results.json" -Value $FinalResults
Logthis "  >> All done. Exiting with code 0.";Exit 0