<#
use this script to store or retrieve azure application registration
credentials.
#>

$ConfigurationDescription = "ACME Tenant Configuration"


# ===============================================
# SNAPSHOT SERVICE PRINCIPAL (required)
# =============================================== 
# This is your registered application with Access
# Control (IAM) assignment for Microsoft Compute
# Contributor role. See documentation for details.
# Use any means to obtain these variable values
# such as CyberArk api and or PSModules.
# ===============================================
$TenantId = "73aa5137-626b-4fc6-851e-07f08cec9d5a"
$ClientId = "05a8a908-82cd-40de-b29c-1ee8ecfe70c7"
$ClientSecret = "M0M8Q~mvD2sB_zWEOABNk4lUN4_A5wg~-RuCIbHb"



# ===============================================
# SAVE SNAPSHOTS (optional)
# =============================================== 
# If you want to save snapshots into a resource
# group other than the group where the AVD
# resides, enter info here. Use "same" to save
# snapshots into the same resource group as the 
# AVD.
# ===============================================
$SaveSnapshotSubscriptionID = "same"
$SaveSnapshotResourceGroupName = "HCSC_APP00047108_DFS_INVESTIGATION"


# end of configuration file.